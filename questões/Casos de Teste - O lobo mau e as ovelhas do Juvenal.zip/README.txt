Arquivo zip gerado em: 07/12/2017 00:51:58 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: O lobo mau e as ovelhas do Juvenal